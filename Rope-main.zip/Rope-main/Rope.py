#!/usr/bin/env python3

from rope import Coordinator
if __name__ == "__main__":
    Coordinator.run()